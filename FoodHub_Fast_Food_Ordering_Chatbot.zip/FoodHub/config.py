"""
config.py
Central configuration for the FoodHub Flask application.

Works in two modes:
  * Local: SQLite file (foodhub.db) in the project folder - zero setup.
  * Production / Vercel: set the DATABASE_URL environment variable to a
    Postgres connection string (Neon, Supabase, Vercel Postgres, ...).
"""

import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
ON_VERCEL = bool(os.environ.get("VERCEL"))


def _database_uri():
    url = os.environ.get("DATABASE_URL") or os.environ.get("POSTGRES_URL")
    if url:
        # Many providers hand out "postgres://", SQLAlchemy needs "postgresql://"
        if url.startswith("postgres://"):
            url = url.replace("postgres://", "postgresql://", 1)
        return url
    if ON_VERCEL:
        # Vercel's filesystem is read-only except /tmp, and /tmp is wiped
        # regularly. Fine for a quick look, NOT for real data -> set DATABASE_URL.
        return "sqlite:////tmp/foodhub.db"
    return "sqlite:///" + os.path.join(BASE_DIR, "foodhub.db")


class Config:
    # Set FOODHUB_SECRET_KEY in production (any long random string).
    SECRET_KEY = os.environ.get("FOODHUB_SECRET_KEY", "foodhub-dev-secret-key-change-me")

    SQLALCHEMY_DATABASE_URI = _database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    if not SQLALCHEMY_DATABASE_URI.startswith("sqlite"):
        SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True, "pool_recycle": 280}

    # Admin-uploaded food photos are stored IN THE DATABASE (table
    # image_files), so they survive on serverless hosts like Vercel.
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")   # legacy fallback only
    ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "gif", "webp"}
    MAX_CONTENT_LENGTH = 4 * 1024 * 1024                # Vercel body limit is ~4.5 MB

    # Business rules
    DELIVERY_FEE = 150.0               # flat delivery fee (Rs.)
    FREE_DELIVERY_THRESHOLD = 2000.0   # orders above this get free delivery

    # Admin account created on the very first run. In production set
    # ADMIN_USERNAME / ADMIN_PASSWORD before the first deploy.
    DEFAULT_ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "admin")
    DEFAULT_ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")
